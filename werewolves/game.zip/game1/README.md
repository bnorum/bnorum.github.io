# were-wolves
a visual novel about dating werewolves made in renpy

short demo : https://bradynorum.com/werewolves/game.html

DONT LOOK AT THE SCRIPT FILE IF YOU DONT WANNA SPOIL YOURSELF lol
