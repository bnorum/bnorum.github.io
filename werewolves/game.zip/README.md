# were-wolves

A visual novel using the Ren'Py framework.

"We're Wolves" is a visual novel in which you participate in five nights of speed dating.
Over the course of the game,look closely for clues which would suggest that a character is secretly a werewolf.
By the end of the fifth night, you must select which character isn't a werewolf. The moon is full, don't get bit!

Short Demo : https://bradynorum.com/werewolves/game.html

Menu Layouts (WIP) : https://www.figma.com/file/8UsZDW2nY8ntVBJ6LeJVaC/We're-Wolves-Menus?node-id=0%3A1&t=qsuMOod8uIEq39mC-1

To avoid spoilers, don't read too closely into the script file.
You're allowed to look at it! Just don't read it.
But if you aren't gonna play the game, go for it. I just hope you play it :O
