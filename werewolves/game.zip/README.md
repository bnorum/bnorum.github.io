# were-wolves
a visual novel about dating werewolves made in renpy

DONT LOOK AT THE SCRIPT FILE IF YOU DONT WANNA SPOIL YOURSELF lol
