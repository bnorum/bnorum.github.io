#include "types.h"
#include "stat.h"
#include "user.h"

//pass cmd line args
int main(int argc, char * argv[]) {

  printf(1, "root (pid%d)\n", (int) getpid());
  int rc = fork();

  if (rc < 0) printf(1, "Fork failed on root process.\n");
  else if (rc == 0) printf(1, "Child process from root (pid:%d)\n", (int) getpid());
  else printf(1, "Parent of root %d (pid:%d)\n", rc, (int) getpid());

  exit();
}
