#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "memlayout.h"
#include "mmu.h"

int test_num = 123456;

//define address stored in data/text section
int *stack_ptr = (int *) USERTOP - 4;

int main(int argc, char *argv[])
{
	//create two integers, one on the stack, another on the heap

	int *heap_ptr = malloc(sizeof(int));
	
	//print the addresses of the two integers
	printf(1, "address of stack val: %x\n", stack_ptr);
	printf(1, "address of heap ptr: %x\n", heap_ptr);
	
	//compare the addresses of the two integers
	// Test 1 will pass if the address of the stack value is higher than
	// the address of the heap pointer
	if(heap_ptr < stack_ptr)
		printf(1, "TEST 1 PASSED\n");
	else
		exit();
		
	//initialize the stack pointer near the end of user memory
	*stack_ptr = test_num;
	
	//use fork to create a child process with the same address space as above
	int rc = fork();
	if(rc == 0)
	{
		//Test 2 will pass only if the stack is properly copied
		//If not, the kernel will enter a trap
		if(*stack_ptr == test_num)
			printf(1, "TEST 2 PASSED\n");
	}
	else if(rc > 0)
	{
		(void) wait();
		
		//grow the stack by accessing an address one page right
		//below the initial stack page
		char *p = (char *) (USERTOP- PGSIZE - 4);
		*p = 'z';
		
		//Test 3 will pass if the trap is handled properly and
		//the stack grows correctly
		printf(1, "TEST 3 PASSED\n");
	}
	else
		printf(1, "Fork attempt failed.\n");
		
	exit();
}
