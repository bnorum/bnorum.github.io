#include "types.h"
#include "user.h"
#include "mmu.h"
#include "thread.h"


int thread_create(void (*function) (void*), void * arg)
{
	/*
		allocate a page in memory, if page allocated successfully,
		allocate a second page, call clone()
		to clone the page in memory in a new process
	*/
	void * stack = malloc(PGSIZE);
	if(stack == 0) //malloc did not succeed
		return -1;
	if((uint)stack % PGSIZE != 0) //malloc allocated a page in memory
		stack += PGSIZE - ((uint)stack % PGSIZE);
	
	return clone(function, arg, stack);
}

int thread_join(int threadid)
{
	/*
		Assuming: you already called thread_create at least once
		The return value from the corresponding call of thread_create
		denotes the threadid
		
		If your threadid is still valid, pass to thread_join, call
		join() on the memory allocated, bring back into main thread
		
		You cannot call join() on a child thread id which has already
		been joined.
	*/
	int returnValue;
	void * stack;
	returnValue = join(threadid, &stack);
	return returnValue;
}
