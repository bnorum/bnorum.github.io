
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"


// function main
//     clear file open counter
//     open proj1-f1.txt
//     open proj1-f2.txt
//     open proj1-f3.txt
//     close proj1-f1.txt
//     close proj1-f2.txt
//     close proj1-f3.txt
//     if file open counter == 3
//         print success!
//     else
//         print file counter incorrect


int main(int argc, char *argv[]) {
  clearglobalflag();
  int fd1 = open("f1.txt", O_RDONLY);
  int fd2 = open("f2.txt", O_RDONLY);
  int fd3 = open("f3.txt", O_RDONLY);
  close(fd1);
  close(fd2);
  close(fd3);
  printf(1,"%d\n", getglobalflag());
  if (getglobalflag() == 3) printf(0, "Success!\n");
  else printf(0, "File Counter Incorrect\n");
  
  exit();
}
