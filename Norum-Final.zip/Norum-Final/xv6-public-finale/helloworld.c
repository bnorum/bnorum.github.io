#include "types.h"
#include "stat.h"
#include "user.h"

//passing command line args
int main(int argc, char *argv[]) {

    printf(1, "Hello World from Xv6! \n");
    //lil less standard, needs extra arg, 1
    
    exit();
    
}
