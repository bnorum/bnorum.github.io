#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[]) {
  char * str = argv[1];
  for (int i = 0; i <  10; i++) {
    printf(1, "%s\n", str);
  }
  exit();
}
