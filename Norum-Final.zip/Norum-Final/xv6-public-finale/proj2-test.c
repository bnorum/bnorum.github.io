#include "types.h"
#include "user.h"
#include "mmu.h"
#include "param.h"
#include "proc.h"
#include "syscall.h"



void spin (){
  volatile int sink = 0;
  for (;;){
    sink = sink + 1 ;
    sink = sink + 1 ;
    sink = sink + 1 ;
  }
}

int main ( int argc, char *argv[]){
  int tickets[] = { 100 , 200 , 300 };
  int pids[] = { 0 , 0 , 0 };
  for (int i = 0 ; i < 3 ; i++){
    int rc = fork();
    if (rc == 0 ){
      //set the tickets to tickets[i]
      settickets(tickets[i]);
      spin();
      exit();
    }
    else
      pids[i] = rc;
  }
  //Set the tickets to 10
  settickets(10);
  sleep(5000);

  for ( int i = 0 ; i < 3 ; ++i)
    kill(pids[i]);
  for ( int i = 0 ; i < 3 ; ++i)
    wait();
  exit();
}

