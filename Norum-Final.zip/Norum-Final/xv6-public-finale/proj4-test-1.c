#include "types.h"
#include "stat.h"
#include "thread.h"
#include "user.h"

int num = 0;

void function(void * arg) {
  for (int i = 0; i < 5; i++) {
    num++;
    printf(1, "Thread Variable Value: %d\n", num);
    sleep(100);
  }
  
  exit();
}

int main(int argc, char * argv[]) {
  int arg = 1;
  int rc = thread_create(&function, &arg);
  thread_join(rc);
  printf(1, "Parent Variable Value: %d\n", num);
  printf(1, "Parent Thread Terminated.\n");
  exit();

}
