#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char * argv[]) {
    
  int p = 0;
  int * p1 = &p;
  
  printf(1, "Address pointed to by p: %d\n", p1);
  
  for (int i = 0; i < 10; i++) {
    *p1 = *p1 + 1;
    printf(1, "%d \n", *p1);
  }//for i
  
  exit();
}
